# config file for bash-completion
# https://github.com/scop/bash-completion

set (BASH_COMPLETION_VERSION "2.18.0")

set (BASH_COMPLETION_PREFIX "/data/data/app.xodos2/files/usr")

set (BASH_COMPLETION_COMPATDIR "/data/data/app.xodos2/files/usr/etc/bash_completion.d")
set (BASH_COMPLETION_COMPLETIONSDIR "/data/data/app.xodos2/files/usr/share/bash-completion/completions")
set (BASH_COMPLETION_HELPERSDIR "/data/data/app.xodos2/files/usr/share/bash-completion/helpers")

set (BASH_COMPLETION_FOUND "TRUE")
